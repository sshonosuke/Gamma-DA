###------------------------------------------------------------------###
###------------------------------------------------------------------###
###               Code for replicating Table 3                       ###
###------------------------------------------------------------------###
###------------------------------------------------------------------###
## Remark 1: Since the computation time can be different according to 
##           computational environment, the results of CT and sESS can 
##           be different from those in Table 3.
## Remark 2: ESS and MSE in Table 3 can be exactly replicated.  

set.seed(3)
rm(list=ls())

## load R files and packages
library(coda)
source("Sampler_DirMult.R")


## simulation settings 
R <- 100     # number of Monte Carlo replications
n_set <- c(100, 1000)     # sample size
scenario <- c(1, 2)
L <- 10    # number of items
N <- 500    # size in multinomial distribution 

set <- expand.grid(scenario, n_set)[,c(2,1)]   # 4 combinations of (n, scenario)
L <- dim(set)[1]


## arrays to store results
ESS <- array(NA, c(4, L, R))
CT <- array(NA, c(4, L, R))
sESS <- array(NA, c(4, L, R))
MSE <- array(NA, c(4, L, R))

method <- c("DAN", "DAP", "DAPT", "ERG")
dimnames(ESS)[[1]] <- dimnames(sESS)[[1]] <- method
dimnames(CT)[[1]] <- dimnames(MSE)[[1]] <- method


## Monte Carlo replications
for(l in 1:L){
  n <- set[l, 1]
  
  # true shape parameters of Dirichlet distribution
  if(set[l, 2]==1){ true_alpha <- rep(1/L, L) }
  if(set[l, 2]==2){ true_alpha <- 1:L/L }
  
  for(r in 1:R){
    ## data generation 
    ep <- rdirichlet(n, true_alpha)
    x <- matrix(NA, n, L)
    for(i in 1:n){
      x[i,] <- rmultinom(1, size=N, prob=ep[i,])
    }
    
    ## posterior computation 
    start_time <- proc.time()[3]
    DAN_pos <- DAN_sampler(x=x, mc=5000, burn=1000)
    time_DAN <- proc.time()[3] - start_time
    
    start_time <- proc.time()[3]
    DAP_pos <- DAP_sampler(x=x, mc=5000, burn=1000)
    time_DAP <- proc.time()[3] - start_time
    
    start_time <- proc.time()[3]
    DAPT_pos <- DAPT_sampler(x=x, mc=5000, burn=1000)
    time_DAPT <- proc.time()[3] - start_time
    
    start_time <- proc.time()[3]
    ERG_pos <- ERG_sampler(x=x, mc=5000, burn=1000)
    time_ERG <- proc.time()[3] - start_time
    
    ## effective sample size
    ESS[1, l, r] <- mean( apply(DAN_pos, 2, effectiveSize) )
    ESS[2, l, r] <- mean( apply(DAP_pos, 2, effectiveSize) )
    ESS[3, l, r] <- mean( apply(DAPT_pos, 2, effectiveSize) )
    ESS[4, l, r] <- mean( apply(ERG_pos, 2, effectiveSize) )
    
    ## computation time 
    CT[1, l, r] <- time_DAN
    CT[2, l, r] <- time_DAP
    CT[3, l, r] <- time_DAPT
    CT[4, l, r] <- time_ERG
    
    ## effective sample size (per unit second )
    sESS[, l, r] <- ESS[, l, r] / CT[, l, r]   
    
    ## posterior means
    MSE[1, l, r] <- mean( (apply(DAN_pos, 2, mean) - true_alpha)^2 )
    MSE[2, l, r] <- mean( (apply(DAP_pos, 2, mean) - true_alpha)^2 )
    MSE[3, l, r] <- mean( (apply(DAPT_pos, 2, mean) - true_alpha)^2 )
    MSE[4, l, r] <- mean( (apply(ERG_pos, 2, mean) - true_alpha)^2 )
    
    print(r)
  }
  print(l)
}


## Summary 
ESS <- apply(ESS, c(1,2), mean)
CT <- apply(CT, c(1,2), mean)
sESS <- apply(sESS, c(1,2), mean)
MSE <- apply(MSE, c(1,2), mean)

Result <- cbind(rep(set[,1], rep(4, 4)), rep(set[,2], rep(4, 4)), as.vector(ESS), as.vector(CT), as.vector(sESS), as.vector(MSE))
dimnames(Result)[[2]] <- c("n", "scenario", "ESS", "CT", "sESS", "MSE")
write.csv(Result, file="Table3.csv")



