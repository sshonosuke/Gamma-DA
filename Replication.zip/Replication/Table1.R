###------------------------------------------------------------------###
###------------------------------------------------------------------###
###                Code for replicating Table 1                      ###
###------------------------------------------------------------------###
###------------------------------------------------------------------###
## Remark 1: Since the computation time can be different according to 
##           computational environment, the results of sESS can be
##           different from those in Table 1.
## Remark 2: ESS and MSE in Table 1 can be exactly replicated.  
## This code also produces Figures 1, S1 and S2. 

set.seed(111)
rm(list=ls())

## load R files and packages
library(coda)
source("Sampler_t_dist.R")


## simulation settings 
R <- 100     # number of Monte Carlo replications
n_set <- c(10, 30, 100)     # sample size
true_alpha_set <- c(1/10, 1, 10)/2   # true alpha (2*alpha is the degrees of freedom)
true_theta <- 3    # true location parameter
true_tau <- 1   # true scale parameter

set <- expand.grid(true_alpha_set, n_set)[,c(2,1)]   # 9 combinations of (n, alpha)
L <- dim(set)[1]


## arrays to store results
ESS_DA <- array(NA, c(L, R, 3))
ESS_AMH <- array(NA, c(L, R, 3))
sESS_DA <- array(NA, c(L, R, 3))
sESS_AMH <- array(NA, c(L, R, 3))
MSE_DA <- array(NA, c(L, R, 3))
MSE_AMH <- array(NA, c(L, R, 3))



## Monte Carlo replications
for(l in 1:L){
  n <- set[l, 1]
  true_alpha <- set[l, 2]
  true_para <- c(true_theta, true_tau^2, true_alpha)   # true parameter value
  for(r in 1:R){
    # data generation 
    x <- rt(n, df=2*true_alpha) * sqrt(true_tau) + true_theta
    
    ## posterior computation 
    start_time <- proc.time()[3]
    DA_pos <- DA_sampler(x, mc=5000, burn=1000)
    time_DA <- proc.time()[3] - start_time
    
    start_time <- proc.time()[3]
    AMH_pos <- AMH_sampler(x, mc=5000, burn=1000)
    time_AMH <- proc.time()[3] - start_time
    
    # effective sample size
    ESS_DA[l, r, ] <- apply(DA_pos, 2, effectiveSize)
    ESS_AMH[l, r, ] <- apply(AMH_pos, 2, effectiveSize)
    
    # effective sample size (per unit second )
    sESS_DA[l, r, ] <- apply(DA_pos, 2, effectiveSize) / time_DA
    sESS_AMH[l, r, ] <- apply(AMH_pos, 2, effectiveSize) / time_AMH
    
    # squared error
    MSE_DA[l, r, ] <- ( apply(DA_pos, 2, mean) - true_para )^2
    MSE_AMH[l, r, ] <- ( apply(AMH_pos, 2, mean) - true_para )^2
  }
  print(l)
}


## Summary 
mESS_DA <- apply(ESS_DA, c(1,3), mean)
mESS_AMH <- apply(ESS_AMH, c(1,3), mean)
msESS_DA <- apply(sESS_DA, c(1,3), mean)
msESS_AMH <- apply(sESS_AMH, c(1,3), mean)
mMSE_DA <- apply(MSE_DA, c(1,3), mean)
mMSE_AMH <- apply(MSE_AMH, c(1,3), mean)

Order <- c(1, 10, 2, 11, 3, 12, 4, 13, 5, 14, 6, 15, 7, 16, 8, 17, 9, 18)
scenario <- (expand.grid(2*true_alpha_set, n_set)[,c(2,1)])[rep(1:L, rep(2, L)),]  
Result <- cbind(scenario, rbind(mESS_DA, mESS_AMH)[Order,], rbind(msESS_DA, msESS_AMH)[Order,], rbind(matrix(NA, L, 3), mMSE_AMH/mMSE_DA)[Order,])
dimnames(Result)[[2]] <- c("n", "2*alpha_0", "ESS-theta", "ESS-tau", "ESS-alpha", "sESS-theta", "sESS-tau", "sESS-alpha", "MSE-theta", "MSE-tau", "MSE-alpha")
write.csv(Result, file="Table1.csv")



## Figure 1 
pdf("Figure1.pdf", height=12, width=12, pointsize=16)
par(mfcol=c(3, 3))
boxplot(cbind(sESS_DA[1,,3], sESS_AMH[1,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*alpha[0]==1/10)))
boxplot(cbind(sESS_DA[2,,3], sESS_AMH[2,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*alpha[0]==1)))
boxplot(cbind(sESS_DA[3,,3], sESS_AMH[3,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*alpha[0]==10)))
boxplot(cbind(sESS_DA[1,,2], sESS_AMH[1,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*alpha[0]==1/10)))
boxplot(cbind(sESS_DA[2,,2], sESS_AMH[2,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*alpha[0]==1)))
boxplot(cbind(sESS_DA[3,,2], sESS_AMH[3,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*alpha[0]==10)))
boxplot(cbind(sESS_DA[1,,1], sESS_AMH[1,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*alpha[0]==1/10)))
boxplot(cbind(sESS_DA[2,,1], sESS_AMH[2,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*alpha[0]==1)))
boxplot(cbind(sESS_DA[3,,1], sESS_AMH[3,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*alpha[0]==10)))
dev.off()



## Figure S1 
pdf("FigureS1.pdf", height=12, width=12, pointsize=16)
par(mfcol=c(3, 3))
boxplot(cbind(sESS_DA[4,,3], sESS_AMH[4,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*alpha[0]==1/10)))
boxplot(cbind(sESS_DA[5,,3], sESS_AMH[5,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*alpha[0]==1)))
boxplot(cbind(sESS_DA[6,,3], sESS_AMH[6,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*alpha[0]==10)))
boxplot(cbind(sESS_DA[4,,2], sESS_AMH[4,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*alpha[0]==1/10)))
boxplot(cbind(sESS_DA[5,,2], sESS_AMH[5,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*alpha[0]==1)))
boxplot(cbind(sESS_DA[6,,2], sESS_AMH[6,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*alpha[0]==10)))
boxplot(cbind(sESS_DA[4,,1], sESS_AMH[4,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*alpha[0]==1/10)))
boxplot(cbind(sESS_DA[5,,1], sESS_AMH[5,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*alpha[0]==1)))
boxplot(cbind(sESS_DA[6,,1], sESS_AMH[6,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*alpha[0]==10)))
dev.off()



## Figure S2 
pdf("FigureS2.pdf", height=12, width=12, pointsize=16)
par(mfcol=c(3, 3))
boxplot(cbind(sESS_DA[7,,3], sESS_AMH[7,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*alpha[0]==1/10)))
boxplot(cbind(sESS_DA[8,,3], sESS_AMH[8,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*alpha[0]==1)))
boxplot(cbind(sESS_DA[9,,3], sESS_AMH[9,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*alpha[0]==10)))
boxplot(cbind(sESS_DA[7,,2], sESS_AMH[7,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*alpha[0]==1/10)))
boxplot(cbind(sESS_DA[8,,2], sESS_AMH[8,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*alpha[0]==1)))
boxplot(cbind(sESS_DA[9,,2], sESS_AMH[9,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*alpha[0]==10)))
boxplot(cbind(sESS_DA[7,,1], sESS_AMH[7,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*alpha[0]==1/10)))
boxplot(cbind(sESS_DA[8,,1], sESS_AMH[8,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*alpha[0]==1)))
boxplot(cbind(sESS_DA[9,,1], sESS_AMH[9,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*alpha[0]==10)))
dev.off()

