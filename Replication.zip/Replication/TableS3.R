###------------------------------------------------------------------###
###------------------------------------------------------------------###
###                Code for replicating Table S3                     ###
###------------------------------------------------------------------###
###------------------------------------------------------------------###
## Remark 1: Since the computation time can be different according to 
##           computational environment, the results of sESS can be 
##           different from those in Table S3.
## Remark 2: ESS and MSE in Table S3 can be exactly replicated.  

set.seed(222)
rm(list=ls())

## load R files and packages
library(coda)
source("Sampler_t_dist.R")


## simulation settings 
R <- 100     # number of Monte Carlo replications
n_set <- c(10, 30, 100)     # sample size
alpha_min_set <- c(1, 3)/2  # lower bound of alpha (\underbar{alpha} in the paper)
true_alpha <- 10/2    # true alpha (2*alpha is the degrees of freedom)
true_theta <- 3    # true location parameter
true_tau <- 4   # true scale parameter
true_para <- c(true_theta, true_tau^2, true_alpha)   # true parameter value

set <- expand.grid(alpha_min_set, n_set)[,c(2,1)]   # 6 combinations of (n, alpha_min)
L <- dim(set)[1]


## arrays to store results
ESS_DA <- array(NA, c(L, R, 3))
ESS_AMH <- array(NA, c(L, R, 3))
sESS_DA <- array(NA, c(L, R, 3))
sESS_AMH <- array(NA, c(L, R, 3))
MSE_DA <- array(NA, c(L, R, 3))
MSE_AMH <- array(NA, c(L, R, 3))



## Monte Carlo replications
for(l in 1:L){
  n <- set[l, 1]
  for(r in 1:R){
    # data generation 
    x <- rt(n, df=2*true_alpha) * sqrt(true_tau) + true_theta
    
    ## posterior computation 
    start_time <- proc.time()[3]
    DA_pos <- DA_sampler(x, mc=5000, burn=1000, alpha_min=set[l,2])
    time_DA <- proc.time()[3] - start_time
    
    start_time <- proc.time()[3]
    AMH_pos <- AMH_sampler(x, mc=5000, burn=1000, alpha_min=set[l,2])
    time_AMH <- proc.time()[3] - start_time
    
    # effective sample size
    ESS_DA[l, r, ] <- apply(DA_pos, 2, effectiveSize)
    ESS_AMH[l, r, ] <- apply(AMH_pos, 2, effectiveSize)
    
    # effective sample size (per unit second )
    sESS_DA[l, r, ] <- apply(DA_pos, 2, effectiveSize) / time_DA
    sESS_AMH[l, r, ] <- apply(AMH_pos, 2, effectiveSize) / time_AMH
    
    # squared error
    MSE_DA[l, r, ] <- ( apply(DA_pos, 2, mean) - true_para )^2
    MSE_AMH[l, r, ] <- ( apply(AMH_pos, 2, mean) - true_para )^2
  }
  print(l)
}





## Summary 
mESS_DA <- apply(ESS_DA, c(1,3), mean)
mESS_AMH <- apply(ESS_AMH, c(1,3), mean)
msESS_DA <- apply(sESS_DA, c(1,3), mean)
msESS_AMH <- apply(sESS_AMH, c(1,3), mean)
mMSE_DA <- apply(MSE_DA, c(1,3), mean)
mMSE_AMH <- apply(MSE_AMH, c(1,3), mean)

Order <- c(1, 7, 2, 8, 3, 9, 4, 10, 5, 11, 6, 12)
scenario <- (expand.grid(2*alpha_min_set, n_set)[,c(2,1)])[rep(1:L, rep(2, L)),]  
Result <- cbind(scenario, rbind(mESS_DA, mESS_AMH)[Order,], rbind(msESS_DA, msESS_AMH)[Order,], rbind(matrix(NA, L, 3), mMSE_AMH/mMSE_DA)[Order,])
dimnames(Result)[[2]] <- c("n", "2*underbar{alpha}", "ESS-theta", "ESS-tau", "ESS-alpha", "sESS-theta", "sESS-tau", "sESS-alpha", "MSE-theta", "MSE-tau", "MSE-alpha")
write.csv(Result, file="TableS3.csv")
