###------------------------------------------------------------------###
###------------------------------------------------------------------###
###                Code for replicating Table 2                      ###
###------------------------------------------------------------------###
###------------------------------------------------------------------###
## Remark 1: Since the computation time can be different according to 
##           computational environment, the results of sESS can be 
##           different from those in Table 2.
## Remark 2: ESS and MSE in Table 2 can be exactly replicated.  
## This code also produces Figures 2, S3 and S4. 

set.seed(222)
rm(list=ls())

## load R files and packages
library(coda)
source("Sampler_t_dist.R")


## simulation settings 
R <- 100     # number of Monte Carlo replications
n_set <- c(10, 30, 100)     # sample size
alpha_min_set <- c(1, 3)/2  # lower bound of alpha (\underbar{alpha} in the paper)
true_alpha <- 10/2    # true alpha (2*alpha is the degrees of freedom)
true_theta <- 3    # true location parameter
true_tau <- 1   # true scale parameter
true_para <- c(true_theta, true_tau^2, true_alpha)   # true parameter value

set <- expand.grid(alpha_min_set, n_set)[,c(2,1)]   # 6 combinations of (n, alpha_min)
L <- dim(set)[1]


## arrays to store results
ESS_DA <- array(NA, c(L, R, 3))
ESS_AMH <- array(NA, c(L, R, 3))
sESS_DA <- array(NA, c(L, R, 3))
sESS_AMH <- array(NA, c(L, R, 3))
MSE_DA <- array(NA, c(L, R, 3))
MSE_AMH <- array(NA, c(L, R, 3))



## Monte Carlo replications
for(l in 1:L){
  n <- set[l, 1]
  for(r in 1:R){
    # data generation 
    x <- rt(n, df=2*true_alpha) * sqrt(true_tau) + true_theta
    
    ## posterior computation 
    start_time <- proc.time()[3]
    DA_pos <- DA_sampler(x, mc=5000, burn=1000, alpha_min=set[l,2])
    time_DA <- proc.time()[3] - start_time
    
    start_time <- proc.time()[3]
    AMH_pos <- AMH_sampler(x, mc=5000, burn=1000, alpha_min=set[l,2])
    time_AMH <- proc.time()[3] - start_time
    
    # effective sample size
    ESS_DA[l, r, ] <- apply(DA_pos, 2, effectiveSize)
    ESS_AMH[l, r, ] <- apply(AMH_pos, 2, effectiveSize)
    
    # effective sample size (per unit second )
    sESS_DA[l, r, ] <- apply(DA_pos, 2, effectiveSize) / time_DA
    sESS_AMH[l, r, ] <- apply(AMH_pos, 2, effectiveSize) / time_AMH
    
    # squared error
    MSE_DA[l, r, ] <- ( apply(DA_pos, 2, mean) - true_para )^2
    MSE_AMH[l, r, ] <- ( apply(AMH_pos, 2, mean) - true_para )^2
  }
  print(l)
}





## Summary 
mESS_DA <- apply(ESS_DA, c(1,3), mean)
mESS_AMH <- apply(ESS_AMH, c(1,3), mean)
msESS_DA <- apply(sESS_DA, c(1,3), mean)
msESS_AMH <- apply(sESS_AMH, c(1,3), mean)
mMSE_DA <- apply(MSE_DA, c(1,3), mean)
mMSE_AMH <- apply(MSE_AMH, c(1,3), mean)

Order <- c(1, 7, 2, 8, 3, 9, 4, 10, 5, 11, 6, 12)
scenario <- (expand.grid(2*alpha_min_set, n_set)[,c(2,1)])[rep(1:L, rep(2, L)),]  
Result <- cbind(scenario, rbind(mESS_DA, mESS_AMH)[Order,], rbind(msESS_DA, msESS_AMH)[Order,], rbind(matrix(NA, L, 3), mMSE_AMH/mMSE_DA)[Order,])
dimnames(Result)[[2]] <- c("n", "2*underbar{alpha}", "ESS-theta", "ESS-tau", "ESS-alpha", "sESS-theta", "sESS-tau", "sESS-alpha", "MSE-theta", "MSE-tau", "MSE-alpha")
write.csv(Result, file="Table2.csv")



## Figure 2 
pdf("Figure2.pdf", height=8, width=12, pointsize=16)
par(mfcol=c(2, 3))
boxplot(cbind(sESS_DA[1,,3], sESS_AMH[1,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*underline(alpha)==1)))
boxplot(cbind(sESS_DA[2,,3], sESS_AMH[2,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*underline(alpha)==3)))
boxplot(cbind(sESS_DA[1,,2], sESS_AMH[1,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*underline(alpha)==1)))
boxplot(cbind(sESS_DA[2,,2], sESS_AMH[2,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*underline(alpha)==3)))
boxplot(cbind(sESS_DA[1,,1], sESS_AMH[1,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*underline(alpha)==1)))
boxplot(cbind(sESS_DA[2,,1], sESS_AMH[2,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*underline(alpha)==3)))
dev.off()



## Figure S3 
pdf("FigureS3.pdf", height=8, width=12, pointsize=16)
par(mfcol=c(2, 3))
boxplot(cbind(sESS_DA[3,,3], sESS_AMH[3,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*underline(alpha)==1)))
boxplot(cbind(sESS_DA[4,,3], sESS_AMH[4,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*underline(alpha)==3)))
boxplot(cbind(sESS_DA[3,,2], sESS_AMH[3,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*underline(alpha)==1)))
boxplot(cbind(sESS_DA[4,,2], sESS_AMH[4,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*underline(alpha)==3)))
boxplot(cbind(sESS_DA[3,,1], sESS_AMH[3,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*underline(alpha)==1)))
boxplot(cbind(sESS_DA[4,,1], sESS_AMH[4,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*underline(alpha)==3)))
dev.off()



## Figure S4 
pdf("FigureS4.pdf", height=8, width=12, pointsize=16)
par(mfcol=c(2, 3))
boxplot(cbind(sESS_DA[5,,3], sESS_AMH[5,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*underline(alpha)==1)))
boxplot(cbind(sESS_DA[6,,3], sESS_AMH[6,,3]), names=c("DA", "A-MH"), main=expression(alpha~~~~(2*underline(alpha)==3)))
boxplot(cbind(sESS_DA[5,,2], sESS_AMH[5,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*underline(alpha)==1)))
boxplot(cbind(sESS_DA[6,,2], sESS_AMH[6,,2]), names=c("DA", "A-MH"), main=expression(tau~~~~(2*underline(alpha)==3)))
boxplot(cbind(sESS_DA[5,,1], sESS_AMH[5,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*underline(alpha)==1)))
boxplot(cbind(sESS_DA[6,,1], sESS_AMH[6,,1]), names=c("DA", "A-MH"), main=expression(theta~~~~(2*underline(alpha)==3)))
dev.off()





