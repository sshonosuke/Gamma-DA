###------------------------------------------------------------------###
###------------------------------------------------------------------###
###              Code for replicating Table S2                       ###
###------------------------------------------------------------------###
###------------------------------------------------------------------###
## Remark 1: Since the computation time can be different according to 
##           computational environment, the results of sESS can be
##           different from those in Table S2.
## Remark 2: ESS and MSE in Table S2 can be exactly replicated.  

set.seed(111)
rm(list=ls())

## load R files and packages
library(coda)
source("Sampler_t_dist.R")


## simulation settings 
R <- 100     # number of Monte Carlo replications
n_set <- c(10, 30, 100)     # sample size
true_alpha_set <- c(1/10, 1, 10)/2   # true alpha (2*alpha is the degrees of freedom)
true_theta <- 6    # true location parameter
true_tau <- 1   # true scale parameter

set <- expand.grid(true_alpha_set, n_set)[,c(2,1)]   # 9 combinations of (n, alpha)
L <- dim(set)[1]


## arrays to store results
ESS_DA <- array(NA, c(L, R, 3))
ESS_AMH <- array(NA, c(L, R, 3))
sESS_DA <- array(NA, c(L, R, 3))
sESS_AMH <- array(NA, c(L, R, 3))
MSE_DA <- array(NA, c(L, R, 3))
MSE_AMH <- array(NA, c(L, R, 3))



## Monte Carlo replications
for(l in 1:L){
  n <- set[l, 1]
  true_alpha <- set[l, 2]
  true_para <- c(true_theta, true_tau^2, true_alpha)   # true parameter value
  for(r in 1:R){
    # data generation 
    x <- rt(n, df=2*true_alpha) * sqrt(true_tau) + true_theta
    
    ## posterior computation 
    start_time <- proc.time()[3]
    DA_pos <- DA_sampler(x, mc=5000, burn=1000)
    time_DA <- proc.time()[3] - start_time
    
    start_time <- proc.time()[3]
    AMH_pos <- AMH_sampler(x, mc=5000, burn=1000)
    time_AMH <- proc.time()[3] - start_time
    
    # effective sample size
    ESS_DA[l, r, ] <- apply(DA_pos, 2, effectiveSize)
    ESS_AMH[l, r, ] <- apply(AMH_pos, 2, effectiveSize)
    
    # effective sample size (per unit second )
    sESS_DA[l, r, ] <- apply(DA_pos, 2, effectiveSize) / time_DA
    sESS_AMH[l, r, ] <- apply(AMH_pos, 2, effectiveSize) / time_AMH
    
    # squared error
    MSE_DA[l, r, ] <- ( apply(DA_pos, 2, mean) - true_para )^2
    MSE_AMH[l, r, ] <- ( apply(AMH_pos, 2, mean) - true_para )^2
  }
  print(l)
}


## Summary 
mESS_DA <- apply(ESS_DA, c(1,3), mean)
mESS_AMH <- apply(ESS_AMH, c(1,3), mean)
msESS_DA <- apply(sESS_DA, c(1,3), mean)
msESS_AMH <- apply(sESS_AMH, c(1,3), mean)
mMSE_DA <- apply(MSE_DA, c(1,3), mean)
mMSE_AMH <- apply(MSE_AMH, c(1,3), mean)

Order <- c(1, 10, 2, 11, 3, 12, 4, 13, 5, 14, 6, 15, 7, 16, 8, 17, 9, 18)
scenario <- (expand.grid(2*true_alpha_set, n_set)[,c(2,1)])[rep(1:L, rep(2, L)),]  
Result <- cbind(scenario, rbind(mESS_DA, mESS_AMH)[Order,], rbind(msESS_DA, msESS_AMH)[Order,], rbind(matrix(NA, L, 3), mMSE_AMH/mMSE_DA)[Order,])
dimnames(Result)[[2]] <- c("n", "2*alpha_0", "ESS-theta", "ESS-tau", "ESS-alpha", "sESS-theta", "sESS-tau", "sESS-alpha", "MSE-theta", "MSE-tau", "MSE-alpha")
write.csv(Result, file="TableS2.csv")
